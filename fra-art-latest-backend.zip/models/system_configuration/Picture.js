const mongoose = require("mongoose");

const pictureSchema = mongoose.Schema(
  {
    projectLogo: {
      type: String,
      
      default: "jfkjf",
    },
    userAvatar: {
      type: String,
      
      default: "jkdfjkas",
    },
    userBanner: {
      type: String,

      default: "jkdfjkas",
    },
    helpCenterBanner: {
      type: String,
   
      default: "jkdfjkas",
    },
    currenciesIcon: {
      type: String,
   
      default: "jkdfjkas",
    },
  },
  { timestamps: true }
);

const Picture = mongoose.model("Picture", pictureSchema);
module.exports = Picture;
